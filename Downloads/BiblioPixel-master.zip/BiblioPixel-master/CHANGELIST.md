### v1.2.3
Fixing APA102 driver

### v1.2.2
Improved LEDCircle Rendering
Various bug fixes

### v1.2.1
Added DriverAPA102

### v1.2.0
Added LEDPOV, LEDCircle Classes
Added Serial Device Version Support
Added threaded animation support
Improved Serial Device detection

### v1.1.7
Added check for pyserial version 
Forced case insenitive grep for USB ID

### v1.1.6
Bug fix for APA102 support in DriverSerial

### v1.1.5
Bug fixes for AllPixel support

### v1.1.4
Removed debug print statements 

### v1.1.3
Fixed bug with LEDMatrix setRGB/setHSV

### v1.1.1
bug fixes
added Philips Hue driver

### v1.1.0
- Multi-device support
- Device ID Support
- Various bug fixes

### v1.0.0
- Initial release